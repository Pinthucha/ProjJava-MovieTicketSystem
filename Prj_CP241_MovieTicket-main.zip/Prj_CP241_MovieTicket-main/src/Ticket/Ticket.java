package Ticket;
import Movie.MovieInfo;
import Seat.Seat;

//เก็บไว้ใช้ในอนาคต

//public class Ticket {
//    Seat dataSeat;
//    MovieInfo movie;
//
//
//}
