package Movie;

public class Movie2 extends MovieInfo{
    public void MovieInfo(){
        Movie2 m = new Movie2();
    }
    public Movie2(){
        setMovieName("Simpsons");
        setLanguage("TH/EN");
        setTypeMovie("Cartoon");
        setPosterMoviePath("src/picture/Poster2.jpg");
        setTotalTime("210 minute");
    }
}
