package Movie;

public class Movie1 extends MovieInfo{
    public void MovieInfo(){
        Movie1 m = new Movie1();
    }
    public Movie1(){
        setMovieName("BorBor And The Gang");
        setLanguage("TH/EN");
        setTypeMovie("Comedy");
        setPosterMoviePath("src/picture/Poster1.png");
        setTotalTime("120 minute");
    }

}
